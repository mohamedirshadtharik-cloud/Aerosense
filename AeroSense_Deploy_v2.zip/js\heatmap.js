/**
 * AeroSense - Heatmap Logic using Leaflet.js
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize the map (Center on California for demo purposes)
    const map = L.map('aqiMap').setView([37.7749, -122.4194], 9);

    // 2. Set up the dark themed tiles (CartoDB Dark Matter)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(map);

    // 3. Generate Mock Heatmap Data points (lat, lng, intensity)
    // The intensity loosely maps to AQI (0.0 to 1.0)
    function generateMockHeatmapData(centerLat, centerLng, radiusKM, numPoints) {
        const points = [];
        for (let i = 0; i < numPoints; i++) {
            // Random point within circle
            const r = (radiusKM / 111.32) * Math.sqrt(Math.random());
            const theta = Math.random() * 2 * Math.PI;
            
            const pointLat = centerLat + r * Math.cos(theta);
            const pointLng = centerLng + r * Math.sin(theta);
            
            // Generate some hot spots and cool spots mostly
            // Let's bias toward the center for a cohesive "city plume" effect
            const distanceRatio = Math.sqrt(Math.pow(centerLat - pointLat, 2) + Math.pow(centerLng - pointLng, 2)) / (radiusKM / 111.32);
            let intensity = Math.random();
            
            // Higher intensity closer to the center city usually
            if(distanceRatio < 0.3) {
                 intensity = 0.6 + (Math.random() * 0.4); // 0.6 to 1.0
            } else if (distanceRatio < 0.6) {
                 intensity = 0.3 + (Math.random() * 0.4); // 0.3 to 0.7
            } else {
                 intensity = Math.random() * 0.4; // 0.0 to 0.4
            }

            points.push([pointLat, pointLng, intensity * 200]); // Multiplying by 200 to give Leaflet Heat a clear range
        }
        return points;
    }

    // Generate clusters around Bay Area
    let heatData = generateMockHeatmapData(37.7749, -122.4194, 50, 400); // SF
    heatData = heatData.concat(generateMockHeatmapData(37.3382, -121.8863, 40, 300)); // San Jose
    heatData = heatData.concat(generateMockHeatmapData(37.8044, -122.2712, 30, 250)); // Oakland

    // 4. Configure the gradient to map to our UI colors
    const gradient = {
        0.1: '#10b981', // Good
        0.3: '#f59e0b', // Moderate
        0.5: '#f97316', // Unhealthy Sens
        0.7: '#ef4444', // Unhealthy
        0.9: '#8b5cf6', // Very Unhealthy
        1.0: '#881337'  // Hazardous
    };

    // 5. Add heatmap layer
    let heatLayer = L.heatLayer(heatData, {
        radius: 35,
        blur: 25,
        maxZoom: 12,
        max: 200, // Max intensity calibrator
        gradient: gradient
    }).addTo(map);

    // 6. Interaction Logic
    const searchBar = document.getElementById('mapSearch');
    const locateBtn = document.getElementById('btnLocateMe');

    searchBar.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && e.target.value.trim() !== '') {
            // Very simple mock panning
            alert(`Simulating panning map to: ${e.target.value}`);
            e.target.value = '';
            
            // Pan to a random new location in US roughly
            const newLat = 30 + Math.random() * 15;
            const newLng = -120 + Math.random() * 40;
            
            map.flyTo([newLat, newLng], 10);
            
            // Replace heatmap data
            map.removeLayer(heatLayer);
            const newData = generateMockHeatmapData(newLat, newLng, 60, 500);
            heatLayer = L.heatLayer(newData, {
                radius: 35, blur: 25, maxZoom: 12, max: 200, gradient: gradient
            }).addTo(map);
        }
    });

    locateBtn.addEventListener('click', () => {
        locateBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
        setTimeout(() => {
            map.flyTo([37.7749, -122.4194], 11); // Fly back to SF
            locateBtn.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i>';
        }, 800);
    });
});
