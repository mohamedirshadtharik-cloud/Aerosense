/**
 * AeroSense - History Data Logic
 */

const AQI_LEVELS = [
    { max: 50,  color: 'var(--aqi-good)', label: 'Good' },
    { max: 100, color: 'var(--aqi-moderate)', label: 'Moderate' },
    { max: 150, color: 'var(--aqi-unhealthy-sensitive)', label: 'Unhealthy for Sensitive Groups' },
    { max: 200, color: 'var(--aqi-unhealthy)', label: 'Unhealthy' },
    { max: 300, color: 'var(--aqi-very-unhealthy)', label: 'Very Unhealthy' },
    { max: 500, color: 'var(--aqi-hazardous)', label: 'Hazardous' }
];

function getAqiDefinition(value) {
    for (let level of AQI_LEVELS) {
        if (value <= level.max) return level;
    }
    return AQI_LEVELS[AQI_LEVELS.length - 1];
}

document.addEventListener('DOMContentLoaded', () => {
    // 1. Setup default dates in filters
    const today = new Date();
    const lastWeek = new Date();
    lastWeek.setDate(today.getDate() - 7);
    
    document.getElementById('endDate').valueAsDate = today;
    document.getElementById('startDate').valueAsDate = lastWeek;

    // 2. Generate and Render Mock Data Table
    function renderHistoryTable(days) {
        const tbody = document.getElementById('historyTableBody');
        tbody.innerHTML = '';
        
        let totalAqi = 0;
        let maxAqi = 0;
        let goodDaysCount = 0;
        
        // Use a seeded approach for consistency on demo
        let baseAqi = 45; 
        
        for (let i = 0; i < days; i++) {
            const dateStr = new Date(today.getTime() - (i * 24 * 60 * 60 * 1000)).toLocaleDateString('en-US', { 
                month: 'short', day: 'numeric', year: 'numeric' 
            });
            
            // Generate 3 readings per day for table density
            for(let j = 0; j < 3; j++) {
                const timeStr = j === 0 ? "8:00 AM" : j === 1 ? "2:00 PM" : "8:00 PM";
                
                // Random walk for AQI
                baseAqi = Math.max(10, Math.min(250, baseAqi + (Math.random() - 0.45) * 40));
                const aqi = Math.round(baseAqi);
                
                // Track stats
                totalAqi += aqi;
                if(aqi > maxAqi) maxAqi = aqi;
                if(j===1 && aqi <= 50) goodDaysCount++; // Only testing roughly mid-day for "good day" metric
                
                const def = getAqiDefinition(aqi);
                
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${dateStr} <span style="color: var(--text-muted); font-size: 0.8em; margin-left: 8px;">${timeStr}</span></td>
                    <td><i class="fa-solid fa-location-dot" style="color: var(--text-muted);"></i> San Francisco, CA</td>
                    <td style="font-weight: 700; font-size: 1.1rem;">${aqi}</td>
                    <td>
                        <span class="status-badge" style="background-color: ${def.color}; color: ${aqi > 100 ? '#fff' : '#0f172a'};">${def.label}</span>
                    </td>
                    <td>${(aqi * 0.25).toFixed(1)}</td>
                    <td>${(aqi * 0.4).toFixed(1)}</td>
                    <td>${(aqi * 0.6).toFixed(1)}</td>
                `;
                tbody.appendChild(tr);
            }
        }
        
        // Update summary cards
        const avg = Math.round(totalAqi / (days * 3));
        const avgDef = getAqiDefinition(avg);
        const maxDef = getAqiDefinition(maxAqi);
        
        const elAvg = document.getElementById('avgAqi');
        elAvg.textContent = avg;
        elAvg.style.color = avgDef.color;
        
        const elMax = document.getElementById('maxAqi');
        elMax.textContent = maxAqi;
        elMax.style.color = maxDef.color;
        
        document.getElementById('goodDays').textContent = `${goodDaysCount} / ${days}`;
    }

    // Initial load
    renderHistoryTable(parseInt(document.getElementById('rangeFilter').value));
    
    // Interactions
    document.getElementById('rangeFilter').addEventListener('change', (e) => {
        renderHistoryTable(parseInt(e.target.value));
    });
    
    document.getElementById('btnExport').addEventListener('click', () => {
        const btn = document.getElementById('btnExport');
        btn.innerHTML = '<i class="fa-solid fa-check" style="color: var(--aqi-good);"></i>';
        setTimeout(() => {
            alert("Exported air_quality_history_export.csv to your downloads folder!");
            btn.innerHTML = '<i class="fa-solid fa-download"></i>';
        }, 1000);
    });
});
