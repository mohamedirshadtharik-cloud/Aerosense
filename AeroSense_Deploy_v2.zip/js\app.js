/**
 * AeroSense - Main Application Logic
 * Handles data fetching, UI updates, and interactions.
 */

// ==========================================
// Constants & Configuration
// ==========================================

const AQI_LEVELS = [
    { max: 50,  color: 'var(--aqi-good)', label: 'Good', advice: 'Air quality is considered satisfactory, and air pollution poses little or no risk. Enjoy your outdoor activities.' },
    { max: 100, color: 'var(--aqi-moderate)', label: 'Moderate', advice: 'Air quality is acceptable; however, there may be a moderate health concern for a very small number of individuals who are unusually sensitive to air pollution.' },
    { max: 150, color: 'var(--aqi-unhealthy-sensitive)', label: 'Unhealthy for Sensitive Groups', advice: 'Members of sensitive groups may experience health effects. The general public is not likely to be affected. Reduce prolonged or heavy exertion outdoors.' },
    { max: 200, color: 'var(--aqi-unhealthy)', label: 'Unhealthy', advice: 'Everyone may begin to experience health effects; members of sensitive groups may experience more serious health effects. Avoid prolonged outdoor exertion.' },
    { max: 300, color: 'var(--aqi-very-unhealthy)', label: 'Very Unhealthy', advice: 'Health alert: everyone may experience more serious health effects. Avoid all outdoor physical activities.' },
    { max: 500, color: 'var(--aqi-hazardous)', label: 'Hazardous', advice: 'Health warnings of emergency conditions. The entire population is more likely to be affected. Remain indoors.' }
];

// Determine level based on US EPA breakpoints
function getAqiDefinition(value) {
    for (let level of AQI_LEVELS) {
        if (value <= level.max) {
            return level;
        }
    }
    return AQI_LEVELS[AQI_LEVELS.length - 1]; // Fallback to hazardous
}

// ==========================================
// DOM Elements
// ==========================================
const DOM = {
    location: document.getElementById('displayLocation'),
    aqiValue: document.getElementById('currentAqiValue'),
    aqiProgress: document.getElementById('aqiProgress'),
    aqiStatusText: document.getElementById('aqiStatusText'),
    aqiDescription: document.getElementById('aqiDescription'),
    healthAdviceText: document.getElementById('healthAdviceText'),
    searchBar: document.getElementById('locationSearch'),
    btnLocateMe: document.getElementById('btnLocateMe'),
    lastUpdated: document.getElementById('lastUpdatedTime'),
    
    // Weather
    weatherTemp: document.getElementById('weatherTemp'),
    weatherWind: document.getElementById('weatherWind'),
    weatherHum: document.getElementById('weatherHum'),
    
    // Metrics
    metrics: {
        pm25: { val: document.getElementById('valPm25'), bar: document.getElementById('barPm25'), max: 500 },
        pm10: { val: document.getElementById('valPm10'), bar: document.getElementById('barPm10'), max: 604 },
        no2:  { val: document.getElementById('valNo2'),  bar: document.getElementById('barNo2'),  max: 2049 },
        o3:   { val: document.getElementById('valO3'),   bar: document.getElementById('barO3'),   max: 604 }
    },
    
    chartSelect: document.getElementById('chartMetricSelect'),
    chartCanvas: document.getElementById('trendsChart'),
    
    // Map
    dashboardMapContainer: document.getElementById('dashboardMap')
};

let trendsChartInstance = null;
let dashboardMapInstance = null;
let dashboardHeatLayer = null;
let currentAirData = null;

// ==========================================
// Mock Data Generation
// ==========================================
// Data Fetching logic (Mixing real Open-Meteo with mock pollutants)
async function fetchAirAndWeatherData(locationName, lat = 52.52, lng = 13.41) {
    // 1. Fetch real weather data from Open-Meteo
    let weatherData = null;
    try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,wind_speed_10m,relative_humidity_2m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m`;
        const response = await fetch(url);
        weatherData = await response.json();
    } catch (err) {
        console.error("Failed to fetch weather data", err);
    }

    // 2. Mock AQI based vaguely on real wind speed (higher wind = lower AQI generally)
    let baseAqi = 42;
    if (weatherData && weatherData.current && weatherData.current.wind_speed_10m !== undefined) {
        const wind = weatherData.current.wind_speed_10m;
        // Inverse relationship mock:
        baseAqi = Math.max(10, Math.floor(150 - (wind * 5))); 
    } else {
        baseAqi = Math.floor(Math.random() * 300);
    }

    // Generate pollutants roughly correlated with AQI
    const multiplier = baseAqi / 100;
    const aqi = baseAqi;
    
    return {
        location: locationName,
        aqi: aqi,
        weather: weatherData ? weatherData.current : null,
        pollutants: {
            pm25: (12 * multiplier + Math.random() * 10).toFixed(1),
            pm10: (20 * multiplier + Math.random() * 20).toFixed(1),
            no2: (25 * multiplier + Math.random() * 10).toFixed(1),
            o3: (40 * multiplier + Math.random() * 15).toFixed(1)
        },
        timestamp: new Date().toLocaleTimeString(),
        history: weatherData && weatherData.hourly ? generateFromRealData(weatherData.hourly, aqi) : generateHistoricalData(aqi, 24)
    };
}

function generateFromRealData(hourly, currentAqi) {
    const data = { aqi: [], pm25: [], temp: [], humidity: [], labels: [] };
    
    // Find index of current hour in the array (assuming the array starts from midnight of current day or similar)
    // For simplicity of this demo, let's just take the last 24 hours of available data up to current time roughly.
    // In a real app we'd parse the time strings properly.
    
    // Open meteo returns many days, we just want the 24 hours leading up to now.
    const nowISO = new Date().toISOString().slice(0, 14) + "00"; // e.g. 2022-07-01T15:00
    
    // Fallback if we can't find exact match, just take first 24
    let endIndex = 24; 
    for(let i=0; i<hourly.time.length; i++) {
        if(hourly.time[i] >= nowISO) {
            endIndex = i;
            break;
        }
    }
    
    const startIndex = Math.max(0, endIndex - 24);
    
    let aqiWalk = currentAqi; // We walk backwards to ensure current AQI matches the gauge
    
    for (let i = endIndex - 1; i >= startIndex; i--) {
        // Time label
        const dateObj = new Date(hourly.time[i]);
        data.labels.unshift(`${dateObj.getHours()}:00`); // unshift because we are iterating backwards
        
        data.temp.unshift(hourly.temperature_2m[i]);
        data.humidity.unshift(hourly.relative_humidity_2m[i]);
        
        // Random walk for mocked AQI/PM25
        if (i < endIndex - 1) {
           aqiWalk = Math.max(10, Math.min(500, aqiWalk + (Math.random() - 0.4) * 30));
        } else {
           aqiWalk = currentAqi; // Guarantee last point matches exactly
        }
        data.aqi.unshift(Math.round(aqiWalk));
        data.pm25.unshift((aqiWalk / 4 + Math.random() * 5).toFixed(1));
    }
    return data;
}

function generateHistoricalData(currentAqi, hours) {
    const data = { aqi: [], pm25: [], labels: [] };
    let aqiWalk = currentAqi;
    
    // Generate backwards in time
    for (let i = hours - 1; i >= 0; i--) {
        const d = new Date();
        d.setHours(d.getHours() - i);
        data.labels.push(`${d.getHours()}:00`);
        
        // Random walk ending at current AQI
        if (i > 0) {
           aqiWalk = Math.max(10, Math.min(500, aqiWalk + (Math.random() - 0.4) * 30));
        } else {
           aqiWalk = currentAqi; // Ensure last point matches exactly
        }
        
        data.aqi.push(Math.round(aqiWalk));
        data.pm25.push((aqiWalk / 4 + Math.random() * 5).toFixed(1));
    }
    return data;
}

// ==========================================
// UI Update Logic
// ==========================================
function updateDashboard(data) {
    currentAirData = data;
    const aqiDef = getAqiDefinition(data.aqi);
    
    // Update texts
    DOM.location.innerHTML = `<i class="fa-solid fa-location-dot"></i> ${data.location}`;
    DOM.aqiValue.textContent = data.aqi;
    DOM.aqiStatusText.textContent = aqiDef.label;
    DOM.aqiStatusText.style.color = aqiDef.color;
    
    // For description, we'll keep it static or dynamically adjust based on general data
    DOM.healthAdviceText.textContent = aqiDef.advice;
    DOM.lastUpdated.textContent = data.timestamp;
    
    // Animate AQI Circle
    // Circle dasharray is 283. Max AQI is ~500.
    const percentage = Math.min(data.aqi / 500, 1);
    const offset = 283 - (283 * percentage);
    DOM.aqiProgress.style.strokeDashoffset = offset;
    DOM.aqiProgress.style.stroke = aqiDef.color;
    
    // Glow effect based on color
    const hexColor = aqiDef.color.match(/var\(--aqi-(.+)\)/) 
        ? getComputedStyle(document.documentElement).getPropertyValue(`--aqi-${aqiDef.color.match(/var\(--aqi-(.+)\)/)[1]}`) 
        : aqiDef.color;

    // Update Weather
    if (data.weather) {
        if(DOM.weatherTemp) DOM.weatherTemp.innerHTML = `<i class="fa-solid fa-temperature-half"></i> ${data.weather.temperature_2m}°C`;
        if(DOM.weatherWind) DOM.weatherWind.innerHTML = `<i class="fa-solid fa-wind"></i> ${data.weather.wind_speed_10m} km/h`;
        if(DOM.weatherHum) DOM.weatherHum.innerHTML = `<i class="fa-solid fa-droplet"></i> ${data.weather.relative_humidity_2m}%`;
    }
        
    // Update Pollutants
    for (const [key, element] of Object.entries(DOM.metrics)) {
        const val = data.pollutants[key];
        element.val.textContent = val;
        
        // Calculate bar width (naive normalization for visual effect)
        let percent = (val / element.max) * 100;
        // Boost low values visually so empty bars don't look broken
        if(percent < 5) percent = 5;
        if(percent > 100) percent = 100;
        
        element.bar.style.width = `${percent}%`;
        element.bar.style.backgroundColor = aqiDef.color; // Sync bar colors to overall AQI mood
    }
    
    // Update Chart
    updateChart(DOM.chartSelect.value);
}

// ==========================================
// Charting Logic
// ==========================================
function initChart() {
    const ctx = DOM.chartCanvas.getContext('2d');
    
    // Global defaults
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.font.family = "'Outfit', sans-serif";
    
    trendsChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'AQI Value',
                data: [],
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: '#0f172a',
                pointBorderColor: '#3b82f6',
                pointBorderWidth: 2,
                pointRadius: 3,
                pointHoverRadius: 6,
                fill: true,
                tension: 0.4 // Smooth curves
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false // Hide default legend
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleColor: '#f8fafc',
                    bodyColor: '#f8fafc',
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    borderWidth: 1,
                    padding: 10,
                    displayColors: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index',
            },
        }
    });

    // Initialize the Dashboard Map
    if (DOM.dashboardMapContainer) {
        dashboardMapInstance = L.map('dashboardMap').setView([52.52, 13.41], 10);
        
        // Add dark theme base layer
        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
            subdomains: 'abcd',
            maxZoom: 20
        }).addTo(dashboardMapInstance);
        
        // Disable scroll zoom for the embedded dashboard map so it doesn't block page scrolling
        dashboardMapInstance.scrollWheelZoom.disable();
    }
}

function updateChart(metricKey) {
    if (!trendsChartInstance || !currentAirData) return;
    
    const dataObj = currentAirData.history[metricKey];
    
    trendsChartInstance.data.labels = currentAirData.history.labels;
    trendsChartInstance.data.datasets[0].data = dataObj;
    trendsChartInstance.data.datasets[0].label = metricKey.toUpperCase() + ' Value';
    
    // Dynamically color line based on current AQI color if metric is AQI
    if (metricKey === 'aqi') {
        const aqiDef = getAqiDefinition(currentAirData.aqi);
        const colorVar = aqiDef.color; 
        
        trendsChartInstance.data.datasets[0].borderColor = colorVar;
        trendsChartInstance.data.datasets[0].pointBorderColor = colorVar;
        trendsChartInstance.data.datasets[0].backgroundColor = 'rgba(255, 255, 255, 0.05)';
    } else if (metricKey === 'temp') {
        trendsChartInstance.data.datasets[0].borderColor = '#f59e0b'; // Amber for temp
        trendsChartInstance.data.datasets[0].pointBorderColor = '#f59e0b';
    } else if (metricKey === 'humidity') {
        trendsChartInstance.data.datasets[0].borderColor = '#06b6d4'; // Cyan for humidity
        trendsChartInstance.data.datasets[0].pointBorderColor = '#06b6d4';
    } else {
        // Default blue for specific pollutants
        trendsChartInstance.data.datasets[0].borderColor = '#3b82f6';
        trendsChartInstance.data.datasets[0].pointBorderColor = '#3b82f6';
    }
    
    trendsChartInstance.update();
}


// ==========================================
// Initialization & Events
// ==========================================
async function loadLocation(locationName, lat = 52.52, lng = 13.41) {
    // Show loading state
    DOM.location.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Loading...`;
    
    const data = await fetchAirAndWeatherData(locationName, lat, lng);
    updateDashboard(data);
    
    // Pan small map overview if it exists
    if (dashboardMapInstance) {
        dashboardMapInstance.flyTo([lat, lng], 10);
        
        // Add a simple marker to show the located spot on the dashboard
        dashboardMapInstance.eachLayer((layer) => {
            if (layer instanceof L.Marker || layer instanceof L.Circle) {
                dashboardMapInstance.removeLayer(layer);
            }
        });
        
        // Get the color for the marker
        const aqiDef = getAqiDefinition(data.aqi);
        const colorVar = aqiDef.color;
        const styles = getComputedStyle(document.body);
        const hexColor = styles.getPropertyValue(colorVar.replace('var(', '').replace(')', '')).trim() || '#3b82f6';
        
        L.circleMarker([lat, lng], {
            radius: 12,
            fillColor: hexColor,
            color: '#fff',
            weight: 2,
            opacity: 1,
            fillOpacity: 0.8
        }).addTo(dashboardMapInstance).bindPopup(`<b>${locationName}</b><br>AQI: ${data.aqi}`).openPopup();
    }
}

function handleSearch(e) {
    if (e.key === 'Enter') {
        const val = e.target.value.trim();
        if (val) {
            loadLocation(val);
            e.target.value = '';
        }
    }
}

function handleGeolocation() {
    DOM.btnLocateMe.classList.add('loading');
    DOM.btnLocateMe.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
    
    // Simulate reverse geocoding
    setTimeout(() => {
        DOM.btnLocateMe.classList.remove('loading');
        DOM.btnLocateMe.innerHTML = '<i class="fa-solid fa-location-crosshairs"></i>';
        loadLocation("Berlin, DE", 52.52, 13.41); // Real Coordinates for the requested test
    }, 1000);
}

// Boot up
document.addEventListener('DOMContentLoaded', () => {
    initChart();
    
    // Event Listeners
    DOM.searchBar.addEventListener('keypress', handleSearch);
    DOM.btnLocateMe.addEventListener('click', handleGeolocation);
    DOM.chartSelect.addEventListener('change', (e) => updateChart(e.target.value));
    
    // Load initial default location (Berlin)
    loadLocation("Berlin, DE", 52.52, 13.41);
});
